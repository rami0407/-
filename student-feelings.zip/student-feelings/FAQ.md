# ❓ الأسئلة الشائعة (FAQ)

## 📋 أسئلة عامة

### ❓ هل النظام مجاني؟
✅ **نعم تماماً!** جميع الأدوات المستخدمة مجانية:
- GitHub Pages: استضافة مجانية
- Firebase: خطة مجانية تكفي لمعظم الاستخدامات (50,000 قراءة/يوم)

### ❓ هل أحتاج خبرة برمجية؟
⚠️ **للاستخدام الأساسي: لا**
- رفع الملفات: سهل جداً
- التعديلات البسيطة: لا تحتاج خبرة

✅ **للتخصيصات المتقدمة: خبرة HTML/CSS/JavaScript مفيدة**

### ❓ هل البيانات آمنة؟
🔐 **نعم!** البيانات مخزنة في Firebase Firestore:
- تشفير تلقائي
- نسخ احتياطي تلقائي
- يمكن إضافة قواعد أمان إضافية

### ❓ كم عدد الطلاب الذي يدعمه النظام؟
📊 في الخطة المجانية من Firebase:
- **50,000 قراءة يومياً**
- **20,000 كتابة يومياً**

هذا يكفي لـ:
- 500 طالب يسجلون مشاعرهم يومياً
- عشرات المعلمين يراجعون البيانات

### ❓ هل يعمل على الهواتف؟
✅ **نعم!** التصميم متجاوب بالكامل ويعمل على:
- الهواتف الذكية 📱
- الأجهزة اللوحية 📱
- أجهزة الكمبيوتر 💻

---

## 🔧 حل المشاكل التقنية

### ⚠️ المشكلة: الصفحة لا تظهر (خطأ 404)

**الأسباب المحتملة:**
1. GitHub Pages لم يتم تفعيله
2. الموقع لا يزال قيد النشر (يستغرق 1-5 دقائق)
3. اسم المستودع أو الملف خاطئ

**الحلول:**
```
✅ تأكد من تفعيل GitHub Pages في الإعدادات
✅ انتظر 5 دقائق ثم حدث الصفحة
✅ تأكد من الرابط: https://USERNAME.github.io/REPO-NAME/
✅ تأكد أن الملف اسمه index.html بالضبط (حساس لحالة الأحرف)
```

### ⚠️ المشكلة: النموذج لا يرسل البيانات

**الأسباب المحتملة:**
1. خطأ في إعدادات Firebase
2. قواعد Firestore مغلقة
3. مشكلة في الاتصال بالإنترنت

**الحلول:**
```javascript
// 1. تحقق من Console في المتصفح (F12)
// 2. تأكد من قواعد Firestore:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true; // للاختبار فقط!
    }
  }
}
```

⚠️ **تحذير أمني**: القاعدة أعلاه تسمح بالقراءة والكتابة للجميع. استخدمها للاختبار فقط!

### قواعد أكثر أماناً:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /feelings/{document} {
      allow write: if true; // السماح بالكتابة للجميع
      allow read: if false; // منع القراءة (فقط عبر لوحة التحكم)
    }
  }
}
```

### ⚠️ المشكلة: لوحة التحكم لا تعرض البيانات

**الخطوات:**
1. افتح Console (F12) وابحث عن أخطاء
2. تأكد من الاتصال بالإنترنت
3. تحقق من قواعد Firestore للقراءة

**كود فحص الاتصال:**
```javascript
// أضف هذا الكود في dashboard.html للفحص
console.log("Firebase initialized:", app);
console.log("Firestore initialized:", db);

db.collection('feelings').get()
    .then(snapshot => {
        console.log("Number of documents:", snapshot.size);
    })
    .catch(error => {
        console.error("Error:", error);
    });
```

### ⚠️ المشكلة: الأحرف العربية تظهر رموزاً غريبة

**السبب:** ترميز الملف ليس UTF-8

**الحل:**
```html
<!-- تأكد من وجود هذا السطر في <head> -->
<meta charset="UTF-8">
```

وعند حفظ الملف في المحرر، اختر:
- **Encoding**: UTF-8
- **Line Endings**: LF (Unix)

### ⚠️ المشكلة: التنسيقات لا تظهر

**الأسباب:**
1. CSS لم يتم تحميله
2. مشكلة في الـ Cache

**الحل:**
```
✅ حدث الصفحة بقوة: Ctrl + F5 (Windows) أو Cmd + Shift + R (Mac)
✅ امسح الكاش من المتصفح
✅ جرب متصفحاً مختلفاً
```

### ⚠️ المشكلة: الموقع بطيء

**الحلول:**
1. قلل عدد الاستعلامات من Firebase
2. استخدم التخزين المؤقت (Caching)
3. حدد عدد السجلات المعروضة

**مثال - تحديد عدد السجلات:**
```javascript
const snapshot = await db.collection('feelings')
    .orderBy('timestamp', 'desc')
    .limit(100) // عرض آخر 100 سجل فقط
    .get();
```

---

## 🔐 أسئلة الأمان والخصوصية

### ❓ كيف أحمي لوحة التحكم؟

**خيارات:**

**1. حماية بسيطة (للبداية):**
```javascript
const password = prompt("كلمة المرور:");
if (password !== "مُشيرفة2024") {
    window.location.href = "index.html";
}
```

**2. Firebase Authentication (محترف):**
```javascript
const auth = firebase.auth();

auth.onAuthStateChanged((user) => {
    if (!user) {
        // إعادة توجيه لصفحة تسجيل الدخول
        window.location.href = "login.html";
    }
});
```

**3. جعل المستودع خاصاً:**
- اجعل مستودع GitHub خاصاً (Private)
- شارك الرابط فقط مع المعلمين

### ❓ هل يمكن للطلاب رؤية بيانات بعضهم؟

**لا!** 
- صفحة النموذج (index.html) تسمح فقط بالإرسال
- لوحة التحكم منفصلة تماماً
- يمكنك حماية dashboard.html بكلمة مرور

### ❓ هل يمكنني حذف البيانات القديمة؟

**نعم، بطريقتين:**

**1. من لوحة Firebase Console:**
- اذهب إلى Firestore
- حدد السجلات
- اضغط Delete

**2. برمجياً (تلقائي):**
```javascript
// حذف البيانات الأقدم من 30 يوماً
async function deleteOldData() {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const snapshot = await db.collection('feelings')
        .where('timestamp', '<', thirtyDaysAgo)
        .get();
    
    snapshot.forEach(doc => {
        doc.ref.delete();
    });
}
```

---

## 📊 أسئلة الاستخدام

### ❓ كيف أشجع الطلاب على استخدام النظام؟

**أفكار:**
1. 🎨 اجعله جزءاً من الروتين الصباحي
2. 🏆 نظام نقاط/مكافآت للمشاركة المنتظمة
3. 📱 صمم بوستر أو ملصق مع QR Code للموقع
4. 👥 شارك قصص نجاح (بدون ذكر أسماء)
5. 🎯 اجعل الأمر ممتعاً - أضف ميزات تفاعلية

### ❓ كيف أستفيد من البيانات؟

**استخدامات:**
1. 🔍 **التعرف المبكر**: اكتشف الطلاب الذين يحتاجون دعماً
2. 📊 **تقييم البرامج**: قس تأثير البرامج على مشاعر الطلاب
3. 🗓️ **أنماط زمنية**: حدد الأوقات/الأيام الصعبة
4. 👨‍🏫 **تقارير للإدارة**: قدم إحصائيات دورية
5. 👪 **تواصل مع الأهل**: شارك التقارير (دون أسماء)

### ❓ هل يمكن إضافة لغات أخرى؟

**نعم!** يمكنك:
1. إنشاء نسخة عبرية: `index-he.html`
2. إنشاء نسخة إنجليزية: `index-en.html`
3. أو استخدام نظام ترجمة ديناميكي

**مثال بسيط:**
```javascript
const translations = {
    ar: { title: "كيف تشعر اليوم؟" },
    he: { title: "?איך אתה מרגיש היום" },
    en: { title: "How do you feel today?" }
};

let currentLang = 'ar';
document.getElementById('title').textContent = translations[currentLang].title;
```

---

## 💰 أسئلة التكلفة

### ❓ متى سأحتاج للدفع؟

Firebase تقدم خطة مجانية سخية:
- **50,000 قراءة/يوم**
- **20,000 كتابة/يوم**
- **1 GB تخزين**

ستحتاج للدفع إذا:
- أكثر من 500 طالب يومياً
- الكثير من الزيارات للوحة التحكم
- تخزين ملفات كبيرة

**التكلفة المتوقعة:** إذا تجاوزت الحد، عادة أقل من $5-10/شهر

### ❓ هل GitHub Pages مجاني للأبد؟

✅ **نعم!** للمستودعات العامة، GitHub Pages مجاني تماماً بدون حدود.

---

## 🆘 الحصول على مساعدة

### لم تجد إجابة؟

1. **ابحث في Issues**: تحقق من Issues في المستودع
2. **افتح Issue جديد**: وصف المشكلة بالتفصيل
3. **Documentation**:
   - [توثيق Firebase](https://firebase.google.com/docs)
   - [توثيق GitHub Pages](https://docs.github.com/pages)
4. **المجتمع**:
   - Stack Overflow
   - منتديات Firebase

### معلومات مفيدة عند طلب المساعدة:

```
- نظام التشغيل: (Windows/Mac/Linux)
- المتصفح: (Chrome/Firefox/Safari)
- رسالة الخطأ: (من Console)
- الخطوات المتبعة: (وصف دقيق)
- لقطة شاشة: (إن أمكن)
```

---

## 📚 موارد إضافية

### دروس مفيدة:
- [HTML للمبتدئين](https://www.w3schools.com/html/)
- [CSS للمبتدئين](https://www.w3schools.com/css/)
- [JavaScript للمبتدئين](https://www.w3schools.com/js/)
- [Firebase للمبتدئين](https://firebase.google.com/docs/web/setup)

### أدوات مفيدة:
- [CodePen](https://codepen.io/) - تجربة الأكواد
- [Can I Use](https://caniuse.com/) - توافق المتصفحات
- [CSS Gradient](https://cssgradient.io/) - إنشاء تدرجات

---

💙 **تذكر**: المشروع مفتوح المصدر ونرحب بمساهماتك!
