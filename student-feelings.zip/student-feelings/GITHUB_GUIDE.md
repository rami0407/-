# 📚 دليل الرفع على GitHub

## الخطوة 1️⃣: إنشاء مستودع جديد على GitHub

1. اذهب إلى [github.com](https://github.com) وسجل دخولك
2. اضغط على زر **"New"** أو **"+"** في أعلى الصفحة
3. اختر **"New repository"**
4. املأ المعلومات:
   - **Repository name**: `student-feelings` (أو أي اسم تريده)
   - **Description**: "نظام متابعة مشاعر الطلاب - مدرسة مُشيرفة"
   - اختر **Public** (للنشر العام) أو **Private** (خاص)
   - ✅ لا تضع علامة على "Initialize with README" (لأننا لدينا ملف README جاهز)
5. اضغط **"Create repository"**

## الخطوة 2️⃣: رفع الملفات

### طريقة 1: الرفع المباشر عبر واجهة GitHub (الأسهل)

1. في صفحة المستودع الجديد، اضغط على **"uploading an existing file"**
2. اسحب جميع الملفات التالية:
   - `index.html`
   - `dashboard.html`
   - `README.md`
   - `.gitignore`
3. اكتب رسالة commit مثل: "Initial commit - نظام مشاعر الطلاب"
4. اضغط **"Commit changes"**

### طريقة 2: عبر سطر الأوامر (للمتقدمين)

افتح Terminal أو Command Prompt في مجلد المشروع، ثم نفذ:

```bash
git init
git add .
git commit -m "Initial commit - نظام مشاعر الطلاب"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-feelings.git
git push -u origin main
```

استبدل `YOUR-USERNAME` باسم المستخدم الخاص بك على GitHub.

## الخطوة 3️⃣: تفعيل GitHub Pages

1. في صفحة المستودع، اذهب إلى **Settings** (الإعدادات)
2. من القائمة الجانبية، اختر **Pages**
3. في قسم **"Source"**:
   - اختر **"Deploy from a branch"**
   - اختر الفرع: **main**
   - اختر المجلد: **/ (root)**
4. اضغط **Save**
5. انتظر دقيقة أو دقيقتين، ثم قم بتحديث الصفحة
6. سيظهر رابط موقعك في الأعلى! 🎉

الرابط سيكون على الشكل:
```
https://YOUR-USERNAME.github.io/student-feelings/
```

## الخطوة 4️⃣: اختبار الموقع

1. افتح الرابط في المتصفح
2. جرّب تعبئة النموذج في `index.html`
3. اذهب إلى `dashboard.html` لرؤية البيانات

## 🔐 ملاحظة أمنية مهمة

إذا كنت تريد جعل لوحة التحكم (dashboard) محمية بكلمة مرور:

### إضافة حماية بسيطة:

أضف هذا الكود في بداية ملف `dashboard.html` داخل وسم `<script>`:

```javascript
// حماية بسيطة للوحة التحكم
const password = prompt("أدخل كلمة المرور للوصول إلى لوحة التحكم:");
if (password !== "مُشيرفة2024") { // غيّر كلمة المرور هنا
    alert("كلمة مرور خاطئة!");
    window.location.href = "index.html";
}
```

⚠️ **تنبيه**: هذه حماية بسيطة فقط. للحماية الكاملة، استخدم نظام مصادقة Firebase Auth.

## 📱 مشاركة الموقع

بعد النشر، يمكنك مشاركة الروابط:

- **للطلاب**: `https://YOUR-USERNAME.github.io/student-feelings/`
- **للمعلمين**: `https://YOUR-USERNAME.github.io/student-feelings/dashboard.html`

## 🔄 تحديث الموقع لاحقاً

إذا أردت تحديث الملفات:

### عبر واجهة GitHub:
1. اذهب إلى الملف المراد تعديله
2. اضغط على أيقونة القلم (Edit)
3. قم بالتعديل
4. اضغط **"Commit changes"**

### عبر سطر الأوامر:
```bash
git add .
git commit -m "وصف التحديث"
git push
```

## 🆘 مشاكل شائعة وحلولها

### المشكلة: الصفحة لا تظهر (404)
**الحل**: انتظر 5 دقائق بعد التفعيل، ثم احذف الكاش (Ctrl + F5)

### المشكلة: البيانات لا تُحفظ
**الحل**: تأكد من صحة إعدادات Firebase في الكود

### المشكلة: الصفحة تظهر بدون تنسيق
**الحل**: تأكد من رفع جميع الملفات معاً

## 📞 للدعم

إذا واجهت أي مشكلة، يمكنك:
- فتح Issue في المستودع
- مراجعة [توثيق GitHub Pages](https://docs.github.com/pages)
- التواصل مع الدعم الفني للمدرسة

---

**صُنع بحب في مدرسة مُشيرفة الابتدائية 💙**
